/* Copyright 2005 Tacit Knowledge LLC
 * 
 * Licensed under the Tacit Knowledge Open License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.tacitknowledge.com/licenses-1.0.
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tacitknowledge.filters.clustercheck;

import java.io.IOException;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;

/**
 * Wraps a <code>HttpServletRequest</code> and provides access to cluster-checking
 * <code>HttpSession</code> objects.
 * 
 * @author  Scott Askew (scott@tacitknowledge.com)
 * @version $Id: ClusterCheckingHttpServletRequest.java,v 1.11 2005/02/24 16:01:37 mike Exp $
 */
class ClusterCheckingHttpServletRequest extends HttpServletRequestWrapper
{
    /**
     * The cluster-checking <code>HttpSession</code> wrapper.
     */
    private ClusterCheckingHttpSessionWrapper wrapper = null;
    
    /**
     * Creates a new <code>ClusterCheckingHttpServletRequest</code>.
     * 
     * @param request the <code>HttpServletRequest</code> to wrap.
     */
    public ClusterCheckingHttpServletRequest(HttpServletRequest request)
    {
        super(request);
    }
    
    /**
     * Internally calls getSession(boolean) with a true argument
     *
     * @return HttpSession object
     * @see #getSession(boolean)
     */
    public HttpSession getSession()
    {
        return getSession(true);
    }
    
    /**
     * The main purpose of overriding this method is to return a wrapped session.
     * 
     * @see HttpServletRequestWrapper#getSession(boolean)
     */
    public HttpSession getSession(boolean arg0)
    {
        HttpSession session = super.getSession(arg0);
        if (session != null)
        {
            if ((wrapper == null) 
                || (session.getId() != wrapper.getWrappedSession().getId()))
            {
                wrapper = new ClusterCheckingHttpSessionWrapper(session);
            }
            session = wrapper.getWrappedSession();
        }
        return session;
    }
    
    /**
     * Validates that the use of session attributes will work when an
     * application is deployed in a cluster. 
     * 
     * @return a list of cluster-check violations.  If there were no violations
     *         then an empty list will be returned.
     */
    public List validateSession()
    {
        if (wrapper != null)
        {
            return wrapper.validate();
        }

        return new LinkedList();
    }
    
    /**
     * Returns a Map of session attributes names, along with their
     * serialized size
     *
     * @return Map holding attribute name to serialized attribute size mappings
     * @exception IOException if the serialization used in the calculation fails
     */
    public Map getAttributeSizes() throws IOException
    {
        if (wrapper != null)
        {
            return wrapper.getAttributeSizes();
        }
        
        return new HashMap();   
    }

    /**
     * Helper method that gets the aggregate session size
     *
     * @return int holding the byte count of all the attributes
     * @exception IOException if the serialization used in the calculation fails
     */
    public int getAggregateSize() throws IOException
    {
        if (wrapper != null)
        {
            return wrapper.getAggregateSize();
        }

        return -1;
    }
}
