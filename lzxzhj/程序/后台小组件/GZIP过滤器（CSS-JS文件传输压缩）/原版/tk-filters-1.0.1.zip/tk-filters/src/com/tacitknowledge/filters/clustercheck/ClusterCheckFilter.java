/* Copyright 2005 Tacit Knowledge LLC
 * 
 * Licensed under the Tacit Knowledge Open License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.tacitknowledge.com/licenses-1.0.
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tacitknowledge.filters.clustercheck;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tacitknowledge.filters.GenericFilter;

/**
 * Verifies that all objects in the <code>HttpSession</code> are
 * <code>Serializable</code> and that modifications made to session-scoped objects
 * will be replicated across a cluster.  
 * 
 * @author  Scott Askew (scott@tacitknowledge.com)
 * @version $Id: ClusterCheckFilter.java,v 1.17 2005/03/12 01:52:28 mike Exp $
 */
public class ClusterCheckFilter extends GenericFilter
{
    /**
     * As the request is outbound, this filter validates the session
     * using the ClusterCheckingHttpSessionWrapper.validate() method
     * to make sure that no code has modified entries after they have
     * been put in the session.
     *
     * @param request the request to use
     * @param response the response for the request
     * @param chain the filter chain to add the filter into
     * @exception IOException if the filter chain can't write to the stream
     * @exception ServletException for general servlet problems
     */
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                 FilterChain chain) throws IOException, ServletException
    {
        if (getBooleanConfigEntry("ClusterCheckFilter.Enabled"))
        {
            ClusterCheckingHttpServletRequest requestWrapper =
                new ClusterCheckingHttpServletRequest(request);

            chain.doFilter(requestWrapper, response);

            
            // Capture whether there were any errors with the checks
            boolean errors = false;
            
            
            // Make sure no one is abusing session storage with unset modifications
            if (getBooleanConfigEntry("ClusterCheckFilter.UnsetModificationCheck"))
            {
                if (checkUnsetModification(getFilterConfig().getServletContext(), requestWrapper))
                {
                    errors = true;
                }
            }

            
            // Make sure no one is putting too much into session storage
            if (getBooleanConfigEntry("ClusterCheckFilter.ByteSizeCheck"))
            {
                if (checkAggregateSize(getFilterConfig().getServletContext(), requestWrapper))
                {
                    errors = true;
                }

                if (checkAttributeSizes(getFilterConfig().getServletContext(), requestWrapper))
                {
                    errors = true;
                }
            }

            if (errors && (getBooleanConfigEntry("ClusterCheckFilter.ClientError")))
            {
                response.sendError(500, "Invalid session usage; see log for details");
            }
        }
        else
        {
            chain.doFilter(request, response);
        }
    }
    
    /** {@inheritDoc} */
    public void printBanner(ServletContext context)
    {
        context.log("$Id: ClusterCheckFilter.java,v 1.17 2005/03/12 01:52:28 mike Exp $");
        context.log("\tClusterCheckFilter.Enabled: "
                    + getBooleanConfigEntry("ClusterCheckFilter.Enabled"));
        context.log("\tClusterCheckFilter.UnsetModificationCheck: "
                    + getBooleanConfigEntry("ClusterCheckFilter.UnsetModificationCheck"));
        context.log("\tClusterCheckFilter.ByteSizeCheck: "
                    + getBooleanConfigEntry("ClusterCheckFilter.ByteSizeCheck"));
        context.log("\t\tClusterCheckFilter.AttributeByteSizeLimit: "
                    + getIntConfigEntry("ClusterCheckFilter.AttributeByteSizeLimit", -1));
        context.log("\t\tClusterCheckFilter.AggregateByteSizeLimit: "
                    + getIntConfigEntry("ClusterCheckFilter.AggregateByteSizeLimit", -1));
        context.log("\tClusterCheckFilter.ClientError: "
                    + getBooleanConfigEntry("ClusterCheckFilter.ClientError"));
    }
    
    /**
     * Check for invalid attribute setting
     *
     * @param context The ServletContext to use for logging
     * @param wrapper The request wrapper to work with
     * @return boolean false if there was a problem
     */
    protected boolean checkUnsetModification(ServletContext context, 
                                             ClusterCheckingHttpServletRequest wrapper)
    {
        List errors = wrapper.validateSession();
        if (errors.size() > 0)
        {
            context.log("The HttpSession is not being used in a cluster-friendly way -");
            for (Iterator i = errors.iterator(); i.hasNext();)
            {
                String error = (String) i.next();
                context.log(" --> " + error);
            }
            
            return false;
        }
        
        return true;
    }
    
    /**
     * Check for an aggregate size that's too large
     *
     * @param context The ServletContext to use for logging
     * @param wrapper The request wrapper to work with
     * @return boolean false if there was a problem
     * @exception IOException if there is a problem logging or serializing
     */
    protected boolean checkAggregateSize(ServletContext context, 
                                         ClusterCheckingHttpServletRequest wrapper)
        throws IOException
    {
        int sizeLimit = getIntConfigEntry("ClusterCheckFilter.AggregateByteSizeLimit", -1);
        if (sizeLimit != -1)
        {
            int byteSize = wrapper.getAggregateSize();
            if (byteSize > sizeLimit)
            {
                context.log("AggregateByteSizeLimit exceeded, size: " + byteSize);
                return false;
            }
        }

        return true;
    }
    
    /**
     * Check for an element size that's too large
     *
     * @param context The ServletContext to use for logging
     * @param wrapper The request wrapper to work with
     * @return boolean false if there was a problem
     * @exception IOException if there is a problem logging or serializing
     */
    protected boolean checkAttributeSizes(ServletContext context, 
                                          ClusterCheckingHttpServletRequest wrapper)
        throws IOException
    {
        boolean errors = false;
        int sizeLimit = getIntConfigEntry("ClusterCheckFilter.AttributeByteSizeLimit", -1);
        if (sizeLimit != -1)
        {
            Map sizes = wrapper.getAttributeSizes();
            for (Iterator sizeIter = sizes.keySet().iterator(); sizeIter.hasNext();)
            {
                String attribute = (String) sizeIter.next();
                int byteSize = ((Integer) sizes.get(attribute)).intValue();
                if (byteSize > sizeLimit)
                {
                    context.log("AttributeByteSizeLimit exceeded by "
                                + attribute + ", of size: " 
                                + byteSize);
                    errors = true;
                }
            }
        }

        return !errors;
    }
}
