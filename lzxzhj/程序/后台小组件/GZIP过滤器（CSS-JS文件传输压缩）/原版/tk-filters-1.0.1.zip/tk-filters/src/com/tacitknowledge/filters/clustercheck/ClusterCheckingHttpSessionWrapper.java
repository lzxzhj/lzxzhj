/* Copyright 2005 Tacit Knowledge LLC
 * 
 * Licensed under the Tacit Knowledge Open License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.tacitknowledge.com/licenses-1.0.
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tacitknowledge.filters.clustercheck;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

/**
 * Wraps a <code>HttpSession</code> and validates that the use of session
 * attributes will work when an application is deployed in a cluster. 
 * 
 * @author  Scott Askew (scott@tacitknowledge.com)
 * @version $Id: ClusterCheckingHttpSessionWrapper.java,v 1.12 2005/02/24 16:01:36 mike Exp $
 */
class ClusterCheckingHttpSessionWrapper implements InvocationHandler
{
    /**
     * The real application-server HttpSession
     */
    private HttpSession wrappedSession = null;
    
    /**
     * A replica of the session attributes.  This map will contain the same
     * data that will be replicated across a cluster.
     */
    private Map sessionData = new HashMap();
    
    /**
     * Contains a list of stacktraces for each getAttribute call; this is used
     * to track down code that may have modified session data without calling
     * setAttribute.
     */
    private Map sessionAccessors = new HashMap();
    
    /**
     * Creates a new HttpSessionWrappper
     * 
     * @param session the wrapped session
     */
    public ClusterCheckingHttpSessionWrapper(HttpSession session)
    {
        this.wrappedSession = session;
        mirrorSession();
    }
    
    /**
     * Returns the underlying <code>HttpSession</code>.
     * 
     * @return the underlying <code>HttpSession</code>
     */
    public HttpSession getWrappedSession()
    {
        return (HttpSession) Proxy.newProxyInstance(
            Thread.currentThread().getContextClassLoader(),
            new Class[] {HttpSession.class }, this);
    }

    /**
     * Validates that the use of session attributes will work when an
     * application is deployed in a cluster. 
     * 
     * @return a list of cluster-check violations.  If there were no violations
     *         then an empty list will be returned.
     */
    public List validate()
    {
        List errors = new LinkedList();
        String currentAttributeName = null;
        Enumeration e = null;

        try
        {
            e = wrappedSession.getAttributeNames();
        }
        catch (IllegalStateException ise)
        {
            // This means the session has been invalidated.
            // There isn't anything we can do in this situation.
            return errors;
        }
        
        while (e.hasMoreElements())
        {
            currentAttributeName = (String) e.nextElement();

            try
            {
                ByteArrayOutputStream bos2 = new ByteArrayOutputStream();
                ObjectOutputStream os2 = new ObjectOutputStream(bos2);
                os2.writeObject(wrappedSession.getAttribute(currentAttributeName));
                os2.flush();
                byte[] actualBytes = bos2.toByteArray();
                byte[] controlBytes = (byte[]) sessionData.get(currentAttributeName);
                
                if (!Arrays.equals(controlBytes, actualBytes))
                {
                    StringBuffer buffer = new StringBuffer();
                    buffer.append(currentAttributeName
                                  + " was modified but setAttribute() was not called.");

                    ArrayList accessors = (ArrayList) sessionAccessors.get(currentAttributeName);
                    for (int i = 0; (accessors != null) && (i < accessors.size()); i++)
                    {
                        String accessor = (String) accessors.get(i);
                        buffer.append("\n This was a get after put, it may be the culprit:\n");
                        buffer.append(accessor);
                    }

                    errors.add(new String(buffer));
                }
            }
            catch (NotSerializableException ex)
            {
                errors.add(currentAttributeName + " is not Serializable: " + ex.getMessage());
            }
            catch (IOException ex)
            {
                errors.add("An exception occurred while checking "
                    + currentAttributeName + ": " + ex.getMessage());
            }
            
        }
        return errors;
    }
    
    /**
     * Calculates the size of all the data in the session once its serialized
     *
     * @return Map of attribute names to Integer byte sizes
     * @exception IOException if serialization fails
     */
    public Map getAttributeSizes() throws IOException
    {
        Map sizes = new HashMap();
        
        String currentAttributeName = null;
        Enumeration e = null;
        
        try
        {
            e = wrappedSession.getAttributeNames();
        }
        catch (IllegalStateException ise)
        {
            // This means the session has been invalidated.
            // There's nothing to do in this case
            return sizes;
        }
        
        while (e.hasMoreElements())
        {
            currentAttributeName = (String) e.nextElement();
            
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream os = new ObjectOutputStream(bos);
            os.writeObject(wrappedSession.getAttribute(currentAttributeName));
            os.flush();
            sizes.put(currentAttributeName, new Integer(bos.size()));
        }

        return sizes;
    }
     
    /**
     * Helper method that gets the aggregate session size
     *
     * @return int holding the byte count of all the attributes
     * @exception IOException if the serialization required for the check fails
     */
    public int getAggregateSize() throws IOException
    {
        int aggregateSize = 0;
        
        Map sizes = getAttributeSizes();
        for (Iterator keys = sizes.keySet().iterator(); keys.hasNext();)
        {
            aggregateSize += ((Integer) sizes.get(keys.next())).intValue();
        }

        return aggregateSize;
    }

   /** {@inheritDoc} */
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
    {
        if (method.getName().equals("setAttribute")
            || method.getName().equals("putValue"))
        {
            storeSessionData((String) args[0], args[1]);
        }
        else if (method.getName().equals("getAttribute")
            || method.getName().equals("getValue"))
        {
            getSessionData((String) args[0]);
        }
        else if (method.getName().equals("removeAttribute")
            || method.getName().equals("removeValue"))
        {
            removeSessionData((String) args[0]);
        }
        else if (method.getName().equals("invalidate"))
        {
            invalidateSessionData();
        }

        // Delegate processing to the actual HttpSession implementation
        try
        {
            return method.invoke(wrappedSession, args);
        }
        catch (InvocationTargetException e)
        {
            // unwrap and throw the original exception
            throw e.getTargetException();
        }
    }

    /**
     * Stores the given session attribute internally as a serialized Java object.
     * 
     * @param  key the name of the session attribute to store
     * @param  value the value to store
     * @throws IOException if there was a problem storing the attribute; most
     *         often this will be a <code>NotSerializableException</code>
     */
    private void storeSessionData(String key, Object value) throws IOException
    {
        // Get the serialized version of the value
        ByteArrayOutputStream bos1 = new ByteArrayOutputStream();
        ObjectOutputStream os1 = new ObjectOutputStream(bos1);
        os1.writeObject(value);
        os1.flush();
        byte[] controlBytes = bos1.toByteArray();
        sessionData.put(key, controlBytes);

        // Clear the accessor list - the data has been stored now, so
        // if it gets modified after this, these stacks at least are clear
        sessionAccessors.remove(key);
    }

    /**
     * Returns session data, keeping track of internal accounting as it goes
     *
     * @param key the name of the session attribute to fetch
     */
    private void getSessionData(String key)
    {
        // Get the list of stacks accessing this data
        ArrayList accessors = (ArrayList) sessionAccessors.get(key);
        if (accessors == null)
        {
            accessors = new ArrayList();
        }

        // Get a stack trace for posterity. We will use this later in
        // the "validate()" report if there was illegal access
        Exception e = new Exception();
        StringWriter stack = new StringWriter();
        e.printStackTrace(new PrintWriter(stack));

        // Add the new stack trace to the list of people accessing the key
        accessors.add(new String(stack.getBuffer()));
        sessionAccessors.put(key, accessors);
    }
    
    /**
     * Remove session data and its associated state from the session
     *
     * @param key the name of the session attribute to remove
     */
    private void removeSessionData(String key)
    {
        sessionAccessors.remove(key);
        sessionData.remove(key);
    }
    
    /**
     * invalidate unbinds all session data, so we need to clean up here
     */
    private void invalidateSessionData()
    {
        sessionAccessors.clear();
        sessionData.clear();
    }
    
    /**
     * Replicates each attribute in the underlying session as a serialized Java
     * object. 
     */
    private void mirrorSession()
    {
        Enumeration e = null;
        
        try 
        {
            e = wrappedSession.getAttributeNames();
        }
        catch (IllegalStateException ise)
        {
            // This means the session has been invalidated.
            // There's nothing to do in this case.
            return;
        }
        
        while (e.hasMoreElements())
        {
            String name = (String) e.nextElement();
            Object value = wrappedSession.getAttribute(name);
            try
            {
                storeSessionData(name, value);
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
