/* Copyright 2005 Tacit Knowledge LLC
 * 
 * Licensed under the Tacit Knowledge Open License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.tacitknowledge.com/licenses-1.0.
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tacitknowledge.filters.cache;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tacitknowledge.filters.GenericFilter;

/**
 * Sets "Expires" headers on any resources mapped under this filter.  The
 * expiration duration is defined in the tk-filters.properties file under the
 * <code><i>filtername</i>.ExpirationMinutes</code> property.
 * <p>
 * This filter can be enabled/disabled at run time just like any other
 * <code>GenericFilter</code>.  
 * 
 * @author  Scott Askew (scott@tacitknowledge.com)
 * @version $Id: CacheHeaderFilter.java,v 1.10 2005/03/12 01:52:28 mike Exp $
 * @see     GenericFilter#isEnabled()
 */
public class CacheHeaderFilter extends GenericFilter
{
    /** The value representing a missing or invalid expiration duration */
    private static final int INVALID_EXPIRATION_TIME = -1;

    /** The key used in the tk-filters properties to define the expiration minutes */
    private String expKey = "";
    
    /** {@inheritDoc} */
    public void init(FilterConfig config)
    {
        super.init(config);
        expKey = getFilterConfig().getFilterName() + ".ExpirationMinutes";
    }

    /**
     * Sets expiration headers while the response is outbound
     *
     * @param request the request to work with
     * @param response the response to set headers on
     * @param chain the filter chain to work with
     * @exception IOException if there is a problem writing the header
     * @exception ServletException shouldn't be thrown
     */
    public void doFilterInternal(HttpServletRequest request,
                                 HttpServletResponse response, 
                                 FilterChain chain) throws IOException, ServletException
    {
        chain.doFilter(request, response);
        if (isEnabled() && !response.isCommitted())
        {
            int expirationMinutes = getExpirationMinutes();
            if (expirationMinutes > INVALID_EXPIRATION_TIME)
            {
                long d = System.currentTimeMillis() + (expirationMinutes * 60 * 1000);
                response.setDateHeader("Expires", d);

                // these educate the browser more thoroughly about cacheability
                response.setHeader("Cache-Control", "private");
                response.setHeader("Pragma", "");
            }
        }
    }
    
    /** {@inheritDoc} */
    public void printBanner(ServletContext context)
    {
        context.log("$Id: CacheHeaderFilter.java,v 1.10 2005/03/12 01:52:28 mike Exp $");
        context.log("\t" + getFilterConfig().getFilterName() + ": " + isEnabled());
        context.log("\t" + getFilterConfig().getFilterName() + ".ExpirationMinutes: "
                    + getExpirationMinutes());
    }
    
    /**
     * Returns the number of minutes before the requested resource should be
     * expired from the client's (or proxy's) local cache.
     * 
     * @return the number of minutes before the requested resource should be
     *         expired from the client's local cache; if undefined, then
     *         <code>INVALID_EXPIRATION_TIME</code> will be returned.
     */
    private int getExpirationMinutes()
    {
        return getIntConfigEntry(expKey, INVALID_EXPIRATION_TIME);
    }
}
