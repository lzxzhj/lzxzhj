/* Copyright 2005 Tacit Knowledge LLC
 * 
 * Licensed under the Tacit Knowledge Open License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.tacitknowledge.com/licenses-1.0.
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tacitknowledge.filters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Used to load files from the classpath, similar to
 * <code>ClassLoader.getResourceAsStream()</code>, but with the ability to
 * detect file modifications.  This class can be used to allow applications to
 * respond to changes in resource files loaded via the classpath without needing
 * to restart the VM.
 * <p>
 * For example:
 * <code>
 *    // <i>Assume that <strong>xmlContent</strong> has been populated previously</i>
 *    
 *    if (classpathFileReader.isModified(pathToXml))
 *    {
 *       InputStream is = classpathFileReader.getResourceAsStream(pathToXml);
 * 
 *       // <i>Re-read <strong>is</strong> into <strong>xmlContent</strong> </i>
 *    }
 * </code>
 * 
 * @author  Scott Askew (scott@tacitknowledge.com)
 * @version $Id: ClasspathFileReader.java,v 1.8 2005/02/24 16:01:37 mike Exp $
 */
class ClasspathFileReader
{
    /**
     * File locations and last modified times of all previously loaded files.
     * Keys are file names relative to the classpath; values are
     * <code>CacheEntry</code>s. 
     */
    private Map cache = new HashMap();
    
    /**
     * The last time the disk was stat'd.  <code>isModified</code> uses this
     * to reduce frequent file access.  
     */
    private long lastTimeDiskWasAccessed = 0L;
    
    /**
     * The number of milliseconds between file accesses.
     */
    private long reloadMillis = 0L;
   
    /**
     * Contains information pertinent to previously loaded files.
     * 
     * @author  Scott Askew (scott@tacitknowledge.com)
     * @version $Id: ClasspathFileReader.java,v 1.8 2005/02/24 16:01:37 mike Exp $
     */
    private class CacheEntry
    {
        /**
         * The full path to the file; used to speed subsequent lookups
         */
        private String fullPath = null;
        
        /**
         * The file's last modification time
         */
        private long lastModTime = 0L;
        
        /**
         * Determines if the file is an actual file on disk, as opposed to a
         * file inside a JAR
         */
        private boolean isFileDirectlyOnDisk = true;

        /**
         * Creates a new <code>CacheEntry</code> for a file contained in a JAR.
         */
        public CacheEntry()
        {
            isFileDirectlyOnDisk = false;
        }
        
        /**
         * Creates a new <code>CacheEntry</code> for a file located directly on
         * disk and not in any archive (.zip, .jar).
         * 
         * @param file the file on disk; may not be <code>null</code>
         */
        public CacheEntry(File file)
        {
            fullPath = file.getAbsolutePath();
            lastModTime = file.lastModified();
        }
        
        /**
         * Determines if the file has been modified since the last time it was
         * loaded
         * 
         * @return <code>true</code> if the file has been modified since the
         *         last time it was loaded; if the file has never been loaded,
         *         or is in a JAR, <code>true</code> will always be returned
         */
        public boolean isModified()
        {
            if (isFileDirectlyOnDisk)
            {
                File file = new File(fullPath);
                if (!file.exists())
                {
                    return true; 
                }
                
                if (lastModTime != file.lastModified())
                {
                    return true;                
                }
            }
            
            return false;
        }
    }

    /**
     * Resolves the given file name, relative to the classpath, and returns a
     * corresponding <code>File</code> object.  Only files that actually exist
     * on their own on disk (as opposed to being in a JAR) will be resolved.
     * 
     * @param  fileName the name of the file to lookup, relative to the classpath
     * @return the requested file
     * @throws FileNotFoundException if the file could not be found
     */
    public File getFile(String fileName) throws FileNotFoundException
    {
        List classpath = getClasspathDirectories();
        String fileSeparator = System.getProperty("file.separator");
        for (Iterator i = classpath.iterator(); i.hasNext();)
        {
            String directory = (String) i.next();
            if (!directory.endsWith(fileSeparator) && !fileName.startsWith(fileSeparator))
            {
                directory = directory + fileSeparator;
            }
            File file = new File(directory + fileName);
            if (file.exists() && file.isFile() && file.canRead())
            {
                cache.put(fileName, new CacheEntry(file));
                return file;
            }
        }
        throw new FileNotFoundException("Could not locate file in classpath");
    }
    
    /**
     * Returns an input stream for reading the specified resource.  This method
     * functions similarly to <code>ClassLoader.getResourceAsStream</code>.
     * 
     * @param  fileName the name of the resource to resolve
     * @return an input stream opened to the requested resource, or <code>null</code>
     *         if the resource could not be found
     */
    public InputStream getResourceAsStream(String fileName)
    {
        try
        {
            return new FileInputStream(getFile(fileName));
        }
        catch (FileNotFoundException e)
        {
            InputStream is = 
                Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
            if (is != null)
            {
                cache.put(fileName, new CacheEntry());
            }
            return is;
        }
    }

    /**
     * Returns <code>true</code> if the given resource has been modified since
     * the last time it was loaded with <code>getResourceAsStream</code>.
     * 
     * @param  fileName the name of the file to check
     * @return <code>true</code> if the given resource has been modified since
     *         the last time it was loaded with <code>getResourceAsStream</code>;
     *         otherwise <code>false</code>.  <code>true</code> will be returned
     *         if the file has never been loaded by <code>getResourceAsStream</code>
     * @see    #getResourceAsStream(String)
     */
    public boolean isModified(String fileName)
    {
        if ((lastTimeDiskWasAccessed + reloadMillis) > System.currentTimeMillis())
        {
            return false;
        }
        
        lastTimeDiskWasAccessed = System.currentTimeMillis();
        
        CacheEntry cacheEntry = (CacheEntry) cache.get(fileName);
        if (cacheEntry != null)
        {
            return cacheEntry.isModified();
        }
        
        return true;
    }
    
    /**
     * Sets the number of seconds between up-to-date checks.  The default is
     * <code>0</code>.
     * 
     * @param seconds the number of seconds between up-to-date checks
     */
    public void setReloadSeconds(int seconds)
    {
        reloadMillis = seconds * 1000;
    }
    
    /**
     * Returns the number of seconds between up-to-date checks.  The default is
     * <code>0</code>.
     * 
     * @return the number of seconds between up-to-date checks
     */
    public int getReloadSeconds()
    {
        return (int) reloadMillis / 1000;
    }
    
    /**
     * Returns the classpath as a list of directories.  Any classpath component
     * that is not a directory will be ignored. 
     * 
     * @return the classpath as a list of directories; if no directories can
     *         be found then an empty list will be returned
     */
    private List getClasspathDirectories()
    {
        List directories = new LinkedList();
        String classpath = System.getProperty("java.class.path");
        String separator = System.getProperty("path.separator");
        StringTokenizer st = new StringTokenizer(classpath, separator);
        while (st.hasMoreTokens())
        {
            String possibleDir = st.nextToken();
            File file = new File(possibleDir);
            if (file.isDirectory())
            {
                directories.add(possibleDir);
            }
        }
        return directories;
    }
}
