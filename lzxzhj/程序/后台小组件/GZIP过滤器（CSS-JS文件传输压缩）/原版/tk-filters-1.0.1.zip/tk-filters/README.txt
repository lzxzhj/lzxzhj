Filters
=======

This package contains a number of filters that do useful
things when enabled on application servers.

There are no external dependencies in this package, so that
its as easy as possible to add the jar to a web application
and configure the filters that are useful.

Sample configuration
--------------------
There is a sample filter configuration file, and a sample
snippet of a J2EE-compliant application server that shows
how to add the filters to the application server and how
to configure the individual servlets. These are both in the
conf directory.

The sample filter configuration file contains some general
documentation for each filter, as well as some very precise
information for each feature on specific filters. It is the
best source of information about what features are available,
what each feature does, and how each feature should be used.


API Documentation
-----------------
javadocs are available in the docs directory


Licensing
----------
The source code is available, licensed under the Apache 2.0
software license. The copyrights are held by their respective
owners, listed at the top of the individual files.


Warning
-------
GZIPFlter is currently not working very well. It needs a
different implementation before it can be trusted.
